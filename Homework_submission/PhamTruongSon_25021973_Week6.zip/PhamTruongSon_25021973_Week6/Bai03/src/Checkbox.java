
interface Checkbox {

    void render();
}
