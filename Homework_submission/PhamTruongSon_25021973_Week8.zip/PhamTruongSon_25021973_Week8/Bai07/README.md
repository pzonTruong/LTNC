# Bài 7: The Discount Inspector

## 1. Kỹ thuật Kiểm thử
* **Equivalence Partitioning (EP):** Chia giá thành 3 vùng: `<0`, `0-100`, `>100`.
* **Boundary Value Analysis (BVA):** Tập trung vào các điểm nhạy cảm: `-0.01, 0, 0.01` và `99.99, 100, 100.01`.
* **Combinatorial Testing:** Đảm bảo mọi cặp (Loại khách hàng, Mức giá) đều được kiểm tra ít nhất một lần.