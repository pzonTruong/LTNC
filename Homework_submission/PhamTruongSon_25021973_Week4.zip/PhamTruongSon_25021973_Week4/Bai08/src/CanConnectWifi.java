interface CanConnectWifi {
    void setupWifi();
}