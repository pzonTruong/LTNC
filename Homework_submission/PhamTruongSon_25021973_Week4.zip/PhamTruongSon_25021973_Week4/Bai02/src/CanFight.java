
interface CanFight {

    void fight();
}
