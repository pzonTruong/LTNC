
interface CanFly {

    void fly();
}
