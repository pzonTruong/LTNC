
interface CanSwim {

    void swim();
}
