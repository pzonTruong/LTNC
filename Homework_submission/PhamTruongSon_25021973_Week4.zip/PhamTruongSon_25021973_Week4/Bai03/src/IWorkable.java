
interface IWorkable {

    void work();
}
